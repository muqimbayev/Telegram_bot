========
handlers
========

Handlers is a simple Django app to write logs into databases. For each
question, visitors can choose between a fixed number of answers.

Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add "handlers" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'handlers',
    ]